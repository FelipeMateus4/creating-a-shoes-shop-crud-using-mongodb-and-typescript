import mongoose, { Document, Schema } from "mongoose";
import bcrypt from "bcryptjs";
import { boolean } from "zod";

export interface IUser extends Document {
  name: string;
  email: string;
  password: string;
  token: string;
  verify: boolean;
  comparePassword: (enteredPassword: string) => Promise<boolean>;
}

const userSchema = new Schema<IUser>({
  name: {
    type: String,
    required: true,
  },
  email: {
    type: String,
    required: true,
    unique: true,
  },
  password: {
    type: String,
    required: true,
  },
  token: {
    type: String,
    required: false,
  },
  verify: {
    type: Boolean,
    default: false,
    
  }
});
// realizado antes de salvar
userSchema.pre("save", async function (next) {
  //verifica se a senha foi modificada, caso não, a criptografia não é necessária
  if (!this.isModified("password")) {
    next();
  }

  const salt = await bcrypt.genSalt(10);
  this.password = await bcrypt.hash(this.password, salt);
});

userSchema.methods.comparePassword = async function (enteredPassword: string) {
  return await bcrypt.compare(enteredPassword, this.password);
};

const User = mongoose.model("User", userSchema, "User");

export default User;